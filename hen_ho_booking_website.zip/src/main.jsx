import React, { useEffect, useMemo, useState } from 'react';
import { createRoot } from 'react-dom/client';
import { createClient } from '@supabase/supabase-js';
import { Heart, CalendarDays, Clock3, ShieldCheck, CheckCircle2, ArrowLeft, Copy, Sparkles, Info } from 'lucide-react';
import './style.css';

const env = import.meta.env;
const configured = Boolean(env.VITE_SUPABASE_URL && env.VITE_SUPABASE_ANON_KEY &&
  !env.VITE_SUPABASE_URL.includes('YOUR_PROJECT') && !env.VITE_SUPABASE_ANON_KEY.includes('YOUR_SUPABASE'));
const supabase = configured ? createClient(env.VITE_SUPABASE_URL, env.VITE_SUPABASE_ANON_KEY) : null;
const FEE = Number(env.VITE_BOOKING_FEE || env.VITE_DEPOSIT_AMOUNT || 500000);
const BANK_ID = env.VITE_BANK_ID || '';
const BANK_ACCOUNT = env.VITE_BANK_ACCOUNT || '';
const BANK_NAME = env.VITE_BANK_NAME || '';
const slots = ['09:00','10:00','11:00','13:00','14:00','15:00','16:00','19:00','20:00','21:00'];
const today = new Date();
const localDate = d => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
const dateLabel = value => new Date(`${value}T12:00:00`).toLocaleDateString('vi-VN',{weekday:'long',day:'2-digit',month:'2-digit',year:'numeric'});
const money = n => new Intl.NumberFormat('vi-VN').format(n) + 'đ';

function App() {
  const [date, setDate] = useState(localDate(today));
  const [taken, setTaken] = useState([]);
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [slot, setSlot] = useState('');
  const [form, setForm] = useState({name:'',phone:'',email:'',note:''});
  const [stage, setStage] = useState('form');
  const [booking, setBooking] = useState(null);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function loadTaken(day) {
    if (!supabase) return;
    setLoadingSlots(true);
    const { data, error } = await supabase.rpc('get_taken_slots', { p_date: day });
    if (!error) setTaken((data || []).map(x => x.time_slot));
    setLoadingSlots(false);
  }
  useEffect(() => { loadTaken(date); setSlot(''); }, [date]);

  const minDate = localDate(today);
  // Uses the static QR image supplied by the site owner. This QR may not prefill amount/reference.
  const qrUrl = '/msb-vietqr.png';

  function change(key, value) { setForm(prev => ({...prev, [key]:value})); }

  async function submit(e) {
    e.preventDefault(); setError('');
    if (!supabase) { setError('Website chưa được cấu hình cơ sở dữ liệu. Chủ website cần điền thông tin Supabase trong file .env.'); return; }
    if (!slot) { setError('Vui lòng chọn một khung giờ còn trống.'); return; }
    if (date < minDate) { setError('Vui lòng chọn ngày hôm nay hoặc ngày trong tương lai.'); return; }
    setBusy(true);
    const reference = `HENHO-${date.replaceAll('-', '')}-${slot.replace(':', '')}`;
    const newId = crypto.randomUUID();
    const { error: insertError } = await supabase.from('bookings').insert({
      id: newId,
      customer_name: form.name.trim(), phone: form.phone.trim(),
      email: form.email.trim() || null, date, time_slot: slot,
      note: form.note.trim() || null, amount: FEE,
      payment_reference: reference, payment_status: 'pending'
    });
    setBusy(false);
    if (insertError) {
      if (insertError.code === '23505') {
        setError('Rất tiếc, khung giờ này vừa có người đặt. Vui lòng chọn giờ khác.');
        loadTaken(date);
      } else setError('Chưa đặt được lịch. Vui lòng kiểm tra lại thông tin hoặc thử lại sau.');
      return;
    }
    setBooking({id:newId, date, time_slot:slot, amount:FEE, payment_reference:reference}); setStage('payment'); loadTaken(date);
  }

  async function copyText(text) {
    try { await navigator.clipboard.writeText(text); } catch {}
  }

  return <div className="page">
    <header className="topbar">
      <a className="brand" href="#"><span className="brand-icon"><Heart size={20} fill="currentColor"/></span><span>hẹn một chút<span className="brand-dot">.</span><small>một cuộc hẹn, một kỷ niệm đẹp</small></span></a>
      <span className="private"><ShieldCheck size={15}/> Thông tin được bảo mật</span>
    </header>
    <main>
      <section className="hero">
        <div className="hero-copy">
          <span className="eyebrow"><Sparkles size={14}/> YOUR LITTLE MOMENT</span>
          <h1>Dành một chút thời gian<br/><em>cho điều đặc biệt.</em></h1>
          <p>Chọn ngày, chọn giờ bạn muốn. Phần còn lại, hãy để cuộc hẹn bắt đầu thật nhẹ nhàng.</p>
          <div className="hero-points"><span><CheckCircle2 size={16}/> Chọn giờ còn trống</span><span><CheckCircle2 size={16}/> Xác nhận lịch rõ ràng</span></div>
        </div>
        <div className="hero-art" aria-label="Minh họa trái tim">
          <div className="sun"></div><div className="art-heart"><Heart size={84} strokeWidth={1.1} fill="currentColor"/></div>
          <span className="float-note note-one">♡ made for a moment</span><span className="float-note note-two">just you & me</span>
        </div>
      </section>

      <section className="booking-layout">
        <div className="booking-card">
          <div className="card-heading"><div><span className="step">01 — YOUR DATE</span><h2>Đặt lịch hẹn</h2><p>Điền thông tin để giữ khung giờ phù hợp với bạn.</p></div><div className="heading-icon"><CalendarDays/></div></div>
          {!configured && <div className="notice"><Info size={18}/><span>Chế độ xem trước: cần cấu hình Supabase để nhận và lưu lịch đặt thật.</span></div>}
          {stage === 'form' ? <form onSubmit={submit}>
            <label className="field-label" htmlFor="date">Bạn muốn hẹn vào ngày nào?</label>
            <input id="date" type="date" min={minDate} value={date} onChange={e=>setDate(e.target.value)} required/>
            <div className="slot-header"><label className="field-label">Chọn khung giờ</label><span><i className="dot available"></i>Còn trống <i className="dot unavailable"></i>Đã đặt</span></div>
            <div className="slots">
              {slots.map(s => {
                const isTaken = taken.includes(s);
                return <button type="button" key={s} disabled={isTaken || loadingSlots || !configured} onClick={()=>setSlot(s)} className={`slot ${slot===s?'selected':''} ${isTaken?'taken':''}`}>
                  <Clock3 size={14}/>{s}{isTaken && <span className="taken-label">Đã đặt</span>}
                </button>
              })}
            </div>
            {loadingSlots && <p className="muted tiny">Đang cập nhật giờ đã đặt…</p>}
            <div className="separator"></div>
            <span className="step">02 — YOUR DETAILS</span>
            <div className="fields-grid">
              <div><label className="field-label" htmlFor="name">Tên của bạn *</label><input id="name" value={form.name} onChange={e=>change('name',e.target.value)} placeholder="Nguyễn Minh Anh" minLength="2" maxLength="100" required/></div>
              <div><label className="field-label" htmlFor="phone">Số điện thoại *</label><input id="phone" type="tel" value={form.phone} onChange={e=>change('phone',e.target.value)} placeholder="09xx xxx xxx" required/></div>
              <div className="full"><label className="field-label" htmlFor="email">Email (không bắt buộc)</label><input id="email" type="email" value={form.email} onChange={e=>change('email',e.target.value)} placeholder="email@example.com"/></div>
              <div className="full"><label className="field-label" htmlFor="note">Lời nhắn (không bắt buộc)</label><textarea id="note" value={form.note} onChange={e=>change('note',e.target.value)} placeholder="Bạn muốn chia sẻ điều gì trước buổi hẹn?" rows="3" maxLength="500"/></div>
            </div>
            {error && <div className="error">{error}</div>}
            <div className="fee-row"><span>Phí đặt lịch / chuyển khoản</span><strong>{money(FEE)}</strong></div>
            <button className="submit" disabled={busy || !configured}>{busy?'Đang giữ lịch…':<>Tiếp tục đặt lịch <span>→</span></>}</button>
            <p className="fineprint"><ShieldCheck size={14}/> Thông tin cá nhân chỉ dành cho chủ website, không hiển thị công khai.</p>
          </form> : <div className="payment">
            <div className="success-icon"><CheckCircle2 size={30}/></div><h3>Đã giữ khung giờ!</h3><p className="muted">Vui lòng chuyển khoản để chủ website kiểm tra và xác nhận lịch.</p>
            <div className="summary"><span>Mã đặt lịch</span><strong>{booking.payment_reference}</strong><button type="button" className="copy" onClick={()=>copyText(booking.payment_reference)}><Copy size={14}/> Sao chép</button></div>
            <div className="summary"><span>Thời gian hẹn</span><strong>{dateLabel(booking.date)} · {booking.time_slot}</strong></div>
            <div className="summary"><span>Số tiền cần chuyển</span><strong className="amount">{money(FEE)}</strong></div>
            <div className="summary"><span>Nội dung chuyển khoản</span><strong>{`HENHO ${booking.date.replaceAll('-','')} ${booking.time_slot.replace(':','')}`}</strong><button type="button" className="copy" onClick={()=>copyText(`HENHO ${booking.date.replaceAll('-','')} ${booking.time_slot.replace(':','')}`)}><Copy size={14}/> Sao chép</button></div>
            {qrUrl ? <div className="qr-wrap"><img src={qrUrl} alt="Mã QR chuyển khoản" /><p>Quét QR bằng ứng dụng ngân hàng, nhập số tiền 500.000đ và dán nội dung chuyển khoản hiển thị phía trên nếu ứng dụng chưa tự điền. Kiểm tra tên người nhận trước khi chuyển.</p></div> :
              <div className="notice"><Info size={18}/><span>Không tải được ảnh QR. Vui lòng liên hệ chủ website để nhận thông tin chuyển khoản.</span></div>}
            <p className="payment-note">Lịch đang ở trạng thái chờ xác nhận thanh toán. Vui lòng chỉ chuyển khoản khi thông tin người nhận chính xác.</p>
            <button className="submit secondary" onClick={()=>{setStage('form');setBooking(null);setSlot('');setForm({name:'',phone:'',email:'',note:''});}}>Quay lại trang đặt lịch</button>
          </div>}
        </div>
        <aside className="side-card">
          <div className="side-top"><span className="step">A LITTLE REMINDER</span><div className="quote-heart"><Heart size={24} fill="currentColor"/></div><h3>Những điều nhỏ<br/>làm nên buổi hẹn đẹp.</h3></div>
          <ul><li><span>01</span><div><strong>Chọn đúng giờ</strong><p>Khung giờ đã có người đặt sẽ tự động khóa khi dữ liệu được kết nối.</p></div></li><li><span>02</span><div><strong>Kiểm tra thông tin</strong><p>Hãy nhập số điện thoại chính xác để tiện liên hệ.</p></div></li><li><span>03</span><div><strong>Chờ xác nhận</strong><p>Chủ lịch sẽ xác minh khoản chuyển trước khi xác nhận cuối cùng.</p></div></li></ul>
          <div className="privacy-box"><ShieldCheck size={20}/><div><strong>Riêng tư là ưu tiên</strong><p>Khách khác chỉ thấy giờ đã kín, không thấy tên hay số điện thoại của bạn.</p></div></div>
        </aside>
      </section>
      <footer><a className="footer-brand" href="#"><Heart size={15} fill="currentColor"/> hẹn một chút.</a><span>Made with care · Một cuộc hẹn đáng nhớ bắt đầu từ đây.</span></footer>
    </main>
  </div>
}
createRoot(document.getElementById('root')).render(<App/>);
