-- Run this file in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.bookings (
  id uuid primary key default gen_random_uuid(),
  customer_name text not null,
  phone text not null,
  email text,
  date date not null,
  time_slot text not null,
  note text,
  amount integer not null default 100000,
  payment_status text not null default 'pending'
    check (payment_status in ('pending','submitted','confirmed','rejected')),
  payment_reference text unique,
  receipt_url text,
  created_at timestamptz not null default now(),
  constraint bookings_one_slot_per_day unique (date, time_slot)
);

alter table public.bookings enable row level security;

-- Anyone may create a booking, but cannot read/update/delete private booking records.
create policy "Anyone can create a booking"
on public.bookings for insert
to anon, authenticated
with check (
  length(trim(customer_name)) between 2 and 100
  and length(regexp_replace(phone, '[^0-9+]', '', 'g')) between 9 and 15
  and date >= current_date
);

-- Safe RPC returns ONLY occupied time slots for the requested day, never customer details.
create or replace function public.get_taken_slots(p_date date)
returns table(time_slot text)
language sql
security definer
set search_path = public
as $$
  select b.time_slot
  from public.bookings b
  where b.date = p_date;
$$;

revoke all on function public.get_taken_slots(date) from public;
grant execute on function public.get_taken_slots(date) to anon, authenticated;

-- IMPORTANT: No public SELECT/UPDATE/DELETE policies on bookings.
-- Owner can view details in Supabase Dashboard > Table Editor > bookings.
-- Do not expose service_role keys in frontend.

-- Optional: create a PRIVATE Storage bucket named "receipts" if later adding receipt uploads.
