# Hẹn Một Chút — website đặt lịch hẹn có QR chuyển khoản

## Có gì trong bản này
- Khách chọn ngày, giờ còn trống, nhập thông tin và gửi yêu cầu đặt lịch.
- Cơ sở dữ liệu dùng chung Supabase; ràng buộc UNIQUE(date, time_slot) ngăn hai khách đặt cùng một giờ, kể cả khi họ bấm đồng thời.
- Một RPC an toàn chỉ trả về khung giờ đã kín, không trả thông tin cá nhân của khách khác.
- Hiển thị QR chuyển khoản VietQR theo cấu hình, kèm mã đặt lịch/nội dung chuyển khoản.
- Chủ website xem thông tin booking trong Supabase Dashboard > Table Editor > bookings.

## Cần cấu hình trước khi chạy
1. Tạo project tại https://supabase.com
2. Mở SQL Editor, chạy toàn bộ `supabase.sql`.
3. Vào Project Settings > API, sao chép Project URL và `anon` key.
4. Sao chép `.env.example` thành `.env`, điền URL/key Supabase và `VITE_BOOKING_FEE`.
5. Ảnh QR MSB bạn cung cấp đã được đặt tại `public/msb-vietqr.png` và sẽ hiển thị ở bước thanh toán.
   - Đây là QR ảnh tĩnh: chưa chắc tự điền số tiền hoặc mã đặt lịch. Khách cần nhập đúng số tiền và nội dung chuyển khoản theo hướng dẫn trên trang.
   - Kiểm tra lại QR bằng ứng dụng ngân hàng trước khi dùng công khai.
5. Cài Node.js bản LTS, tại thư mục này chạy:
   - `npm install`
   - `npm run dev`
6. Để đưa lên mạng, deploy project lên Vercel/Netlify và nhập các biến `.env` ở phần Environment Variables.

## Lưu ý quan trọng về thanh toán
QR chỉ tạo lệnh chuyển khoản; bản này KHÔNG tự xác minh tiền đã vào tài khoản. Chủ website cần kiểm tra giao dịch trong ứng dụng ngân hàng rồi cập nhật `payment_status` trong Supabase. Không ghi thông tin đăng nhập ngân hàng vào website.
Để tự động xác nhận thanh toán, cần tích hợp cổng thanh toán/webhook hợp pháp hoặc dịch vụ đối soát ngân hàng được hỗ trợ.

## Quyền riêng tư và bảo mật
- Không có màn hình công khai xem booking hoặc số điện thoại khách.
- Không đưa `service_role` key vào frontend.
- Chủ website chỉ đăng nhập vào Supabase Dashboard để xem dữ liệu.
- Nếu triển khai rộng, nên bổ sung API/server-side admin panel, giới hạn tần suất đặt lịch, CAPTCHA, thời hạn lưu dữ liệu và quy trình xóa dữ liệu theo yêu cầu.
- Đây là bộ khung cần cấu hình và kiểm thử trước khi dùng thật; chưa phải website đã được deploy công khai.


## Cấu hình theo yêu cầu hiện tại
- Phí đặt lịch mặc định: 500.000đ.
- Nội dung chuyển khoản được tạo tự động theo ngày và giờ đã đặt, định dạng `HENHO YYYYMMDD HHMM` (ví dụ `HENHO 20261009 1900`).
- Trang có nút sao chép nội dung chuyển khoản.
- Ảnh QR hiện tại là ảnh tĩnh bạn gửi. Ảnh này không tự chứa số tiền 500.000đ hay nội dung chuyển khoản theo từng lịch; khách có thể cần nhập/dán nội dung sau khi quét. Để QR tự điền số tiền và nội dung, cần số tài khoản đầy đủ hoặc một QR động tạo từ dữ liệu tài khoản xác minh được.
